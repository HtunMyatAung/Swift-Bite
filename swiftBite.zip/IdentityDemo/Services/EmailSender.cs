﻿namespace IdentityDemo.Services
{
    public class EmailSender
    {
    }
}
