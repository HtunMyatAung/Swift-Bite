﻿namespace IdentityDemo.ViewModels
{
    public class ForgotPasswordViewModel
    {
        public string? Email { get; set; }
    }
}
