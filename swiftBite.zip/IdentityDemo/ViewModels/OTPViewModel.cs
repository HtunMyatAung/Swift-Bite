﻿namespace IdentityDemo.ViewModels
{
    public class OTPViewModel
    {
        public string OTP { get; set; }
    }
}
