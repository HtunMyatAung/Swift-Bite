﻿namespace IdentityDemo.ViewModels
{
    public class UserViewModel
    {
        public string Email { get; set; }
    }
}
