﻿namespace IdentityDemo.Initializers
{
    public interface IRoleInitializer
    {
        Task SeedRolesAsync();
    }
}
